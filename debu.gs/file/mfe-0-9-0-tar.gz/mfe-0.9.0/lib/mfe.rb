# MFE the meta-frontend!
#
# Reducing clutter in ~/bin since 2005.
# 
# By Pete Elmore (1337p337@gmail.com)
# http://debu.gs/mfe
#
# For licensing and copyright information, see the file LICENSE in doc/ .

%w(mfe-config fileutils yaml tempfile etc metaid).each { |x| require(x) }

# This module houses the main logic for MFE.
module MFE
	# Method lookup table for commands
	MLook = {
		'add' => :add_cmd,
		'edit' => :edit_yaml,	# Still the default.  edit_cmd has some bugs.
		'edit-yaml' => :edit_yaml,
		'edit-cmd' => :edit_cmd,
		'show' => :show_cmd,
		'to-shell' => :cmd_to_shell,
		'rm' => :rm_cmd,
		'remove' => :rm_cmd,
	}

	# Possible directories for housing mfe commands.
	Dirnames = [ENV['MFE_HOME'],
				(File.join(ENV['HOME'], '/.mfe') rescue nil),
				File.join(Etc.getpwuid(Process.euid).dir, '/.mfe'),
			   ].compact
	
	# This is the character (or string) that indicates that we will be
	# running an MFE command rather than loading and executing a
	# user-defined command.
	CommandSig = ENV['MFE_COMMAND_SIG'] || '-'

	# Loads a command with the given name
	def load_cmd(name)
		Cmd.load full_path(name)
	end

	# Loads and executes a command named by +name+ with args +argv+.
	def exec_cmd(name, *argv)
		begin
			exec load_cmd(name).expand(argv)
		rescue
			$stderr.puts "Couldn't load and execute #{name}!"
			unless File.exist? full_path(name)
				$stderr.puts "File does not exist."
			end
		end
	end

	# Given a list of command names, show_cmd will print what each one does.
	# In the absense of a list of names, it will print all commands in the
	# .mfe directory.
	def show_cmd(*names)
		if names.empty?
			Dir.open(dirname).each { |f|
				names << f
			}
		end

		names.sort.each { |name|
			puts "#{name}:  #{load_cmd(name).to_s}"
		}
	end

	# Given a name and a list of args, this method prints a shell script
	# that would have the effect of running the command.
	def cmd_to_shell(name, *argv)
		cmd = load_cmd(name)
		puts("#!#{ENV['SHELL'] || Etc.getpwuid(Process.euid).shell}", 
			cmd.expand(argv))
		true
	end

	# Removes commands!  :O
	def rm_cmd(names)
		names.each { |name|
			File.unlink full_path(name)
		}
	end
	
	# Adds a new command.
	def add_cmd(name, *cmd)
		if cmd.empty?
			cmd = edit_yaml(name)
			return false if cmd.to_s.empty?
		else
			cmd = Cmd.new(name, :cmd => cmd)
		end
		cmd.save(dirname!)
	end

	# Allows a user to edit a command via an editor instead of having to put
	# the whole thing on the command line.
	# ...May not work.
	def edit_cmd(name, cmd = nil)
		cmd = load_cmd name unless cmd
		file = Tempfile.open("mfe-#{name}")
		file.write cmd.to_s
		file.close
		system editor, file.path
		contents = File.read(file.path).to_s rescue nil
		if contents.empty?
			file.unlink
			false
		else
			system "#{$0} - add #{name} `cat #{file.path}`"
			file.unlink
			$?.exited?
		end
	end

	# Allows the user to directly edit the YAML of a command.
	def edit_yaml(name, *argv)
		system editor, full_path!(name)
		$?.exited?
	end

	# Returns the first viable directory for the MFE directory.  If none is
	# found, returns nil.  Otherwise, it's guaranteed to always return the 
	# same value.
	def dirname
		dir = Dirnames.find { |d| File.directory?(d) }
		if dir
			# It's important for this to be consistent (and faster anyway).
			meta_def(:dirname) { dir }
			return dir
		end
		nil
	end

	# Returns the dirname, but if it's nil, makes the directory with
	# permissions 0700.
	def dirname!
		return dirname if dirname
		Dir.mkdir(Dirnames.first, 0700)
		dirname
	end

	# Returns the user's (suspected) preferred editor.
	def editor
		ENV['VISUAL'] || 
		ENV['EDITOR'] || 
		'vi'  # Reasonable default.
	end

	# Returns the full path for a given command with name +name+.
	def full_path(name)
		File.join(dirname, name)
	end

	# Returns the full path for a given command with name +name+, and
	# creates the path if it does not exist.
	def full_path!(name)
		fn = File.join(dirname!, name)
		File.open(fn, 'a').close
		fn
	end

	def usage(out = $stderr)
		out.puts [ "",
			"MFE, the meta front-end (#{MFEConfig::URL})",
			"Usage:",
			"#{$0} #{CommandSig} command [args ...]",
			"    Where command is one of",
			"        add name script [args ...]:",
			"            Adds a command named 'name' that executes " +
				"'script [args ...]'.",
			"        show [name(s)]", 
			"            Shows the command(s) named, or all commands if none " +
				"are named.",
			"        edit name",
			"            Runs your favorite editor on the named command.",
			"        to-shell name [args ...]",
			"            Turns the user-defined command into a shell script.",
			"#{$0} your_command [args ...]",
			"    Runs the user-defined command named 'your_command' with the " +
				"specified\n    arguments.",
			"#{$0} ['-h'|'-help'|'--help']",
			"    This help screen.",
			"See the README for more info about usage and influential " +
				"environment\nvariables.",
		]
	end

	def version_string
		"MFE, version #{MFEConfig::Version}."
	end
end

# Represents an individual command
class Cmd
	attr_accessor :name

	# Turns a filename into a command!  Amazing!  Pass the full path.
	def self.load(filename)
		obj = YAML.load(File.read(filename)) rescue nil

		case obj.class.to_s.to_sym
		when :Hash
			Cmd.new(File.basename(filename), obj)
		when :Cmd
			obj
		when :NilClass
			nil
		end
	end

	# +save+, saves the command to a file.
	def save(dirname)
		File.open(File.join(dirname, @name), 'w') { |f|
			YAML.dump(self, f)
		}
	end

	# Creates a new command.  
	def initialize(name, cmdopts)
		@name = name
		@cmd = cmdopts[:cmd]
	end

	# +to_s+ simply returns the command string.
	def to_s
		@cmd.join(' ')
	end

	# Turns the command into a line of shell, fit to be exec()'d or ``'d.
	def expand(argv)
		@cmd.map { |this_arg|
			a = this_arg.dup
			a.gsub!(/\bARGS\b/, argv.join(' '))
			a.gsub!(/\bARGEVAL\[(.*)\]/) { |m|
				argeval = $1
				argv.map! { |frozen_arg|
					arg = frozen_arg.dup
					eval(argeval, binding).to_s
				}
				''
			}
			a.gsub!(/\bEVAL\[(.*)\]/) { |m|
				eval($1, binding).to_s
			}
			a
		}.join(' ')
	end

	# +run+ runs the command, returning the output.
	def run(argv)
		`#{expand argv}`
	end
end

