# This module houses a pile of constants for MFE.
module MFEConfig
	Authors = 'Pete Elmore'
	Email = '1337p337@gmail.com'
	PkgName = 'mfe'
	Version = '0.9.0'
	URL = 'http://debu.gs/mfe'
end
